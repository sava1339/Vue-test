<template>
  <p>Ты на странице Photo!</p>
  <p>Сабака</p>
  <img src="https://cdn.iz.ru/sites/default/files/styles/900x506/public/news-2022-08/20201218_gaf_u40_190.jpeg.jpg?itok=IEogP-rS" alt="">
</template>