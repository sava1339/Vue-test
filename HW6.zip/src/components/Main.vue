<script setup>
import {ref} from "vue";
import Test from "./Test.vue";
import Picture from "./Picture.vue"
import Greeting from "./Greeting.vue"

const counter = ref(0)
const numberFirst = ref(0)
const numberSecond = ref(0)
</script>

<template>
  <Greeting name="Saveliy" />
  <p>{{counter}}</p>
  <p>{{numberFirst + numberSecond}}</p>
  <button @click="counter++">+</button>
  <button @click="counter--">-</button>
  <input type="number" v-model="numberFirst">
  <input type="number" v-model="numberSecond">
  <Test/>
  <Picture/>
</template>

<script>
export default{
  created(){
    console.log('Created hook called')
  },
  updated(){
    console.log('page was updated')
  }
}
</script>