<template>
  <img style="width: 300px; margin-right: 2em" src="https://images.saymedia-content.com/.image/ar_1:1%2Cc_fill%2Ccs_srgb%2Cfl_progressive%2Cq_auto:eco%2Cw_1200/MTk2NzY3MjA5ODc0MjY5ODI2/top-10-cutest-cat-photos-of-all-time.jpg" alt="">
  <img style="width: 300px; margin-right: 2em" src="https://imagesvibe.com/wp-content/uploads/2023/05/Cute-Cat-Images14.jpg" alt="">
  <img style="width: 300px;" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHVHJXQUk57oM_D31TLLVYgjGse0UXUtsdElhNSExmeMjeOrpzT0cDTOQlxOtuD6PsvP8&usqp=CAU" alt="">
</template>