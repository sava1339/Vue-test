<script setup>
import {ref} from "vue";
import Test from "./components/Test.vue";
import Picture from "./components/Picture.vue"

const counter = ref(0)
const numberFirst = ref(0)
const numberSecond = ref(0)
</script>

<template>
  <p>Hello world!</p>
  <p>{{counter}}</p>
  <p>{{numberFirst + numberSecond}}</p>
  <button @click="counter++">+</button>
  <button @click="counter--">-</button>
  <input type="number" v-model="numberFirst">
  <input type="number" v-model="numberSecond">
  <Test/>
  <Picture/>
</template>

<script>
export default{
  created(){
    console.log('Created hook called')
  },
  updated(){
    console.log('page was updated')
  }
}
</script>